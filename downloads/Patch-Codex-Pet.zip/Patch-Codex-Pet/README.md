# Patch — Codex Pet

Patch is a plush Muscovy duck custom pet for the ChatGPT desktop app and compatible Codex terminals.

## Install

1. Copy the included `patch` folder into the `.codex/pets` directory in your home folder.
   - macOS/Linux: `~/.codex/pets/patch`
   - Windows: `%USERPROFILE%\.codex\pets\patch`
2. Open **Settings → Pets** in the ChatGPT desktop app.
3. Select **Refresh**, then choose **Patch**.
4. Enter `/pet` to wake Patch.

The installed folder must contain both `pet.json` and `spritesheet.webp`. Patch uses the v2 desktop-pet format (`1536 × 2288`) and is not compatible with the web pet uploader's older atlas dimensions.

Official instructions: https://developers.openai.com/codex/pets

## SHA-256

```text
880ea282355a161682fdffec8c08ab441ddead41899aa967a2cf2cd008585b35  patch/pet.json
93225f22e0e14632bb253223012b93b0d5c63eb3d23b06b5da69d07b441314a6  patch/spritesheet.webp
```
